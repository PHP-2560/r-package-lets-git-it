## ----setup, include = FALSE----------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ---- fig.show='hold'----------------------------------------------------
library(MedLoans)
pay.per.year(400000, .075, 3, years = 20)

## ---- fig.show='hold'----------------------------------------------------
grow(400000, .075, 3)
payments(496918.8, .075, 48632)

