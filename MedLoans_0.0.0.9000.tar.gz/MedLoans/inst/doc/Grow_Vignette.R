## ----setup, include = FALSE----------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ---- fig.show='hold'----------------------------------------------------
library(MedLoans)
grow(100000, .075, n=1)

## ---- fig.show='hold'----------------------------------------------------
grow(100000, .075, n=8)

